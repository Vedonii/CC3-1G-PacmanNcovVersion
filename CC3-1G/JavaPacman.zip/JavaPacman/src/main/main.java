package main;

import citcs.ve.pacman.PacmanGame;
import citcs.ve.pacman.infra.Display;
import citcs.ve.pacman.infra.Game;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;



public class main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Game game = new PacmanGame();
                Display view = new Display(game);
                JFrame frame = new JFrame();
                frame.setTitle("Pacman(NCOV_19_Version)");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.getContentPane().add(view);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                frame.setResizable(false);
                view.requestFocus();
                view.start();
            }

        });
    }
    
}
