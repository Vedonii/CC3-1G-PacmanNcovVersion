package citcs.ve.pacman;

import citcs.ve.pacman.infra.Actor;

/**
 * PacmanActor class.
 * 
 *
 */
public class PacmanActor extends Actor<PacmanGame> {

    public PacmanActor(PacmanGame game) {
        super(game);
    }

    @Override
    public void update() {
        switch (game.getState()) {
            case INITIALIZING: updateInitializing(); break;
            case CITCS_Presents: updateCITCSPresents(); break;
            case TITLE: updateTitle(); break;
            case READY: updateReady(); break;
            case READY2: updateReady2(); break;
            case PLAYING: updatePlaying(); break;
            case PLAYER_DIED: updatePlayerDied(); break;
            case VIRUS_CATCHED: updateVirusCatched(); break;
            case LEVEL_CLEARED: updateLevelCleared(); break;
            case GAME_OVER: updateGameOver(); break;
        }
    }

    public void updateInitializing() {
    }

    public void updateCITCSPresents() {
    }

    public void updateTitle() {
    }

    public void updateReady() {
    }

    public void updateReady2() {
    }

    public void updatePlaying() {
    }

    public void updatePlayerDied() {
    }

    public void updateVirusCatched() {
    }

    public void updateLevelCleared() {
    }

    public void updateGameOver() {
    }

    // broadcast messages
    
    public void stateChanged() {
    }
    
}
