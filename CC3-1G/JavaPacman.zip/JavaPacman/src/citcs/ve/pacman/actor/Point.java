package citcs.ve.pacman.actor;

import citcs.ve.pacman.PacmanActor;
import citcs.ve.pacman.PacmanGame;
import citcs.ve.pacman.PacmanGame.State;
import java.awt.Rectangle;

/**
 * Point class.
 * 
 * Point that is showed when Virus is captured by Player.
 * 
 */
public class Point extends PacmanActor {
    
    private Player player;
    
    public Point(PacmanGame game, Player player) {
        super(game);
        this.player = player;
    }

    @Override
    public void init() {
        loadFrames("/res/point_0.png", "/res/point_1.png"
                , "/res/point_2.png", "/res/point_3.png");

        collider = new Rectangle(0, 0, 4, 4);
    }

    private void updatePosition(int col, int row) {
        x = col * 8 - 4 - 32;
        y = (row + 3) * 8 + 1;
    }
    
    @Override
    public void updateVirusCatched() {
        yield:
        while (true) {
            switch (instructionPointer) {
                case 0:
                    updatePosition(game.catchedVirus.col, game.catchedVirus.row);
                    player.visible = false;
                    game.catchedVirus.visible = false;
                    int frameIndex = game.currentCatchedVirusScoreTableIndex;
                    frame = frames[frameIndex];
                    game.addScore(game.catchedVirusScoreTable[frameIndex]);
                    game.currentCatchedVirusScoreTableIndex++;
                    waitTime = System.currentTimeMillis();
                    instructionPointer = 1;
                case 1:
                    while (System.currentTimeMillis() - waitTime < 500) {
                        break yield;
                    }
                    player.visible = true;
                    player.updatePosition();
                    game.catchedVirus.visible = true;
                    game.catchedVirus.updatePosition();
                    game.catchedVirus.died();
                    game.setState(State.PLAYING);
                    break yield;
            }
        }
    }

    // broadcast messages

    @Override
    public void stateChanged() {
        visible = false;
        if (game.getState() == State.VIRUS_CATCHED) {
            visible = true;
            instructionPointer = 0;
        }
    }

    public void hideAll() {
        visible = false;
    }
    
}
